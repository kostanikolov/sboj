create view showcountries as
select `geography`.`countries`.`country_name`    AS `Country`,
       `geography`.`continents`.`continent_name` AS `Continent`,
       `geography`.`currencies`.`currency_code`  AS `Currency`
from ((`geography`.`countries` join `geography`.`continents` on ((`geography`.`countries`.`continent_code` =
                                                                  `geography`.`continents`.`continent_code`)))
         join `geography`.`currencies`
              on ((`geography`.`countries`.`currency_code` = `geography`.`currencies`.`currency_code`)))
order by `geography`.`currencies`.`currency_code`;

